from COMPUTERVISION.FaceDetection import Face_det
from COMPUTERVISION.Handtracker import Hand_detector
from COMPUTERVISION.PoseDet import Pose_Det
from COMPUTERVISION.Serialconn import Serial_object